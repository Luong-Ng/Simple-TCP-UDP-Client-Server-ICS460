# Name: Luong Nguyen
# StarID: vv2796uo

from socket import *
import sys
import datetime
import hashlib

# 3 arguments to be taken in by command lines
serverHost = sys.argv[1]  # The servers IP
serverPort1 = sys.argv[2]  # The port number
serverPort = int(serverPort1)

fileName = sys.argv[3]    # Text File or just plain text
try:
    f = open(fileName)
    outputData = f.read()
except FileNotFoundError:
    outputData = fileName

# Calculating the checksum
checksum = hashlib.md5(outputData.encode()).hexdigest()
# Establish UDP connection
clientSocket = socket(AF_INET, SOCK_DGRAM)
try:
    # Sending the text to the server
    clientSocket.sendto(outputData.encode(), (serverHost, serverPort))
    today = datetime.datetime.now() # Get the time when the message was sent

    # Sending the client checksum
    clientSocket.sendto(checksum.encode(), (serverHost, serverPort))
    print(f"Checksum sent: {checksum}")

    # Get the checksum from the server and print it out
    today1, address = clientSocket.recvfrom(1024)
    # Calculating the RTT
    today2 = datetime.datetime.now()
    RTT = today2 - today

    print(f"Server received the message at: {today1.decode()}")
    print(str((today2 - today).microseconds)+'us')
except IOError:
    print("ERROR")