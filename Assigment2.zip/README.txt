Name: Luong Nguyen/ vv2796uo
I got a udp client and a server python in here and test file.
I run both of server and client on cmd.
Here's my cmd lines:
Client: simple_udp_client.py 192.168.0.18 56015 test.txt
or: simple_udp_client.py 192.168.0.18 56015 "HELLO THERE!!!"
Server: simple_udp_server.py 56015
I'm not sure about linux but you might need 'python3' at the beginning.